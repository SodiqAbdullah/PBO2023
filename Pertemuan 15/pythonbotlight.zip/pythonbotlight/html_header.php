<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- loader-->
	  <link href="assets/css/pace.min.css" rel="stylesheet" />
	  <script src="assets/js/pace.min.js"></script>

    <!--plugins-->
    <link href="assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />

    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap-extended.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata&display=swap">
    <!--Theme Styles-->
    <link href="assets/css/dark-theme.css" rel="stylesheet" />
    <link href="assets/css/semi-dark.css" rel="stylesheet" />
    <link href="assets/css/header-colors.css" rel="stylesheet" />
    <style>
        /* Apply the font to specific elements */
        .terminal-text {
            font-family: 'Inconsolata', monospace; /* Use 'monospace' as a fallback */
            font-size: 17px; /* Adjust the font size as needed */
            /* Other styling attributes like color, background, etc. */
        }
    </style>
    <title>SimplePHPBot</title>
  </head>
  <body>
    
<!--start wrapper-->
<div class="wrapper">
       <?php 
       include("layouts/leftmenu.php"); 
       include("layouts/topnav.php");
       ?>
        <!-- start page content wrapper-->
      <div class="page-content-wrapper">
              <!-- start page content-->
              <div class="page-content">