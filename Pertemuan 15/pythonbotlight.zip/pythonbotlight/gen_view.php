<?php
include_once("database.php");
include_once("functions.php");
$tbname=$_GET['table'];
$classname=ucfirst($tbname);
$sql = "SHOW TABLES";
$result = $conn->query($sql);
// Get the protocol (http:// or https://)
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';

// Get the host (e.g., localhost)
$host = $_SERVER['HTTP_HOST'];

// Get the request URI (e.g., /oop/matakuliah/edit/5)
$request_uri = $_SERVER['REQUEST_URI'];

// Combine the parts to create the full URL
$full_url = $protocol . $host . $request_uri;

$currentUrl = $full_url;

// Parse the URL
$parsedUrl = parse_url($currentUrl);

// Reconstruct the base URL
$baseUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'] . '/' . explode('/', trim($parsedUrl['path'], '/'))[0];

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- loader-->
	  <link href="assets/css/pace.min.css" rel="stylesheet" />
	  <script src="assets/js/pace.min.js"></script>

    <!--plugins-->
    <link href="assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />

    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap-extended.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">

    <!--Theme Styles-->
    <link href="assets/css/dark-theme.css" rel="stylesheet" />
    <link href="assets/css/semi-dark.css" rel="stylesheet" />
    <link href="assets/css/header-colors.css" rel="stylesheet" />

    <title>SimplePHPBot</title>
  </head>
  <body>
    
<!--start wrapper-->
<div class="wrapper">
       <?php 
       include("layouts/leftmenu.php"); 
       include("layouts/topnav.php");
       ?>
        <!-- start page content wrapper-->
      <div class="page-content-wrapper">
              <!-- start page content-->
              <div class="page-content">

                <!--start breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                  <div class="breadcrumb-title pe-3">MySQL Tables</div>
                </div>
                <!--end breadcrumb-->
                <div class="card radius-10">
                  <div class="card-body">
                  <table class="table custom-table">
                <thead>
                    <tr>
                        <th scope="col">Table Name</th>
                        <th scope="col">Generate View</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $i=1;
                    $pk = getPrimaryKey($conn,$tbname);
                    $unik = getUnique($conn,$tbname);
                    $photo = CheckPhotoField($conn, $dbname, $tbname);
                ?>
                    <tr scope="row">
                        <td><div class="sedang"><?php echo $tbname; ?></div>
                        <small class="d-block">Primary Key <i class="fadeIn animated bx bx-arrow-from-left"></i> <?php echo $pk; ?></small>
                        <small class="d-block">Unique  Key <i class="fadeIn animated bx bx-arrow-from-left"></i> <?php echo $unik; ?></small></td>
                        <td>
                            <div class="btn-group">
                            <a href="gen_view_tkinterform.php?table=<?php echo $tbname;?>" class="btn btn-primary" target="_blank">Create Win Form</a>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            
                    


              </div>
                <!-- end page content-->
      </div>
         
      <!--Start Back To Top Button-->
      <a href="javaScript:;" class="back-to-top"><ion-icon name="arrow-up-outline"></ion-icon></a>
      <!--End Back To Top Button-->

      <!--start overlay-->
      <div class="overlay nav-toggle-icon"></div>
      <!--end overlay-->

</div>
  <!--end wrapper-->

    <!-- JS Files-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="assets/plugins/metismenu/js/metisMenu.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <!--plugins-->
    <script src="assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>

    <!-- Main JS-->
    <script src="assets/js/main.js"></script>


  </body>
</html>