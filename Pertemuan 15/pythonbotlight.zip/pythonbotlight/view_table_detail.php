<?php
include_once("database.php");
include_once("functions.php");
$tbname=$_GET['table'];
$classname=ucfirst($tbname);
$fieldNames = getAllFieldName($conn, $dbname, $tbname);
$pk = getPrimaryKey($conn, $tbname);
$unik = getUnique($conn, $tbname);
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- loader-->
	  <link href="assets/css/pace.min.css" rel="stylesheet" />
	  <script src="assets/js/pace.min.js"></script>

    <!--plugins-->
    <link href="assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />

    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap-extended.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">

    <!--Theme Styles-->
    <link href="assets/css/dark-theme.css" rel="stylesheet" />
    <link href="assets/css/semi-dark.css" rel="stylesheet" />
    <link href="assets/css/header-colors.css" rel="stylesheet" />

    <title>SimplePHPBot</title>
  </head>
  <body>
    
<!--start wrapper-->
<div class="wrapper">
       <?php 
       include("layouts/leftmenu.php"); 
       include("layouts/topnav.php");
       ?>
        <!-- start page content wrapper-->
      <div class="page-content-wrapper">
          <!-- start page content-->
          <div class="page-content">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-4 row-cols-xxl-4">
              <div class="col">
                <div class="card radius-10 bg-primary">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <div class="">
                        <p class="mb-1 text-white">Project Path</p>
                        <p class="mb-0 text-white"><?php echo $_ENV["PROJECT_PATH"]; ?></p>
                      </div>
                      <div class="ms-auto text-white fs-2">
                        <i class="fadeIn animated bx bx-sitemap"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col">
                    <div class="card radius-10 bg-success">
                      <div class="card-body">
                        <div class="d-flex align-items-center">
                          <div class="">
                            <p class="mb-1 text-white">Database</p>
                            <p class="mb-0 text-white"><?php echo $_ENV["DB_DATABASE"]; ?></p>
                          </div>
                          <div class="ms-auto text-white fs-2">
                                <i class="lni lni-database"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
            </div>
            <div class="col-12 col-xl-12">
              <div class="col">
                <div class="card radius-10">
                  <div class="card-body">
                      <h6 class="text-uppercase mb-3"><?php echo $classname; ?></h6>
                      <table class="table custom-table">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Field Name</th>
                                <th scope="col">Type</th>
                                <th scope="col">Value</th>
                                <th scope="col">Description</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php
                          $i=1;
                          foreach ($fieldNames as $fieldName) {
                            $tipe = getColumnType($conn, $dbname, $tbname, $fieldName);
                          ?>
                          <tr scope="row">
                              <td><?php echo $i; ?></td>
                              <td><a href="#"><?php echo $fieldName; ?></a></td>
                              <td><?php echo $tipe; ?></td>
                              <td>
                                <?php
                                  if($tipe=="enum"){
                                    $enum = getEnumValues($conn, $dbname, $tbname, $fieldName);
                                    $string = join(", ", $enum);
                                    echo $string;
                                  }
                                  if($fieldName==$pk){
                                    echo "Primary Key";
                                  }
                                  if($fieldName==$unik){
                                    echo "Unique Key";
                                  }
                                  if(substr($fieldName, -3)=="_id"){
                                    echo "Foregn Key";
                                  }
                                ?>
                              </td>
                              <td>
                                <?php
                                    if($tipe=="text"){
                                      echo "TinyMCE Editor";
                                    }
                                    if($tipe=="enum"){
                                      echo "Combo Box from ENUM value";
                                    }
                                    if($tipe=="varchar"){
                                      if($fieldName=="photo"){
                                          echo "Upload Input";
                                      } else {
                                          echo "Regular Input";
                                      }
                                    }
                                    if($tipe=="tinyint"){
                                      echo "Checkbox Input";
                                    }
                                    if($tipe=="date"){
                                      echo "Calendar Input";
                                    }
                                    if($tipe=="int"){
                                      if(substr($fieldName, -3)=="_id"){
                                        $table = substr($fieldName, 0, -3);
                                        echo "Combo Box from Table: $table";
                                      } elseif($fieldName==$pk) {
                                        echo "Auto Increment, not Inputable";
                                      } else {
                                        echo "Regular Input";
                                      }
                                      
                                    }

                                ?>
                              </td>
                          </tr>
                          <?php
                              $i++;
                              }
                          ?>
                          </tbody>
                      </table>
                      
                  </div>
                </div>
              </div>
              
              
            </div>
            
            <div class="col-12 col-xl-12">
								<div class="product-wrapper">
							
									<div class="product-grid">
                    
										
										<!--end row-->
									</div>
									<hr>
									
								</div>
							</div>
              <footer class="footer">
                <div class="footer-text">
                  Copyright © 2023 Freddy Wicaksono,  M.Kom. All right reserved.
                </div>
              </footer>
          </div>
          <!-- end page content-->
      </div> 
      <!--Start Back To Top Button-->
      <a href="javaScript:;" class="back-to-top"><ion-icon name="arrow-up-outline"></ion-icon></a>
      <!--End Back To Top Button-->

      <!--start overlay-->
      <div class="overlay nav-toggle-icon"></div>
      <!--end overlay-->
</div>
  <!--end wrapper-->
<!--start footer-->

    <!--end footer-->
    <!-- JS Files-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="assets/plugins/metismenu/js/metisMenu.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <!--plugins-->
    <script src="assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>

    <!-- Main JS-->
    <script src="assets/js/main.js"></script>


  </body>
</html>