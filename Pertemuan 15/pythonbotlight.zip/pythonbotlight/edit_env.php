<?php
include("functions.php");

$conn = $_ENV["DB_CONNECTION"];
$host = $_ENV["DB_HOST"];
$dbname = $_ENV["DB_DATABASE"];
$dbuser = $_ENV["DB_USERNAME"];
$pwd = $_ENV["DB_PASSWORD"];
$charset = $_ENV["DB_CHARSET"];
$port = $_ENV["DB_PORT"];
$baseurl = $_ENV["BASE_URL"];
$basepath = $_ENV["BASE_PATH"];
$projectpath = $_ENV["PROJECT_PATH"];

$msg=null;

include('html_header.php');
?>
<div class="card radius-10 border shadow-none">
        <div class="card-body">
            <h5 class="card-title">Create New Project</h5>
            <div class="my-3 border-top"></div>

        <form name="formEdit" method="POST" action="gen_env.php">
            <input type="hidden" class="form-control" name="submitted" value="1"/>
            <div class="row g-3">
                <div class="col-4">
                    <label>Connection:</label>
                    <select id="conn" name="conn" style="width:150px" 
                    class="form-control show-tick" required>
                    <option value="<?php echo $conn; ?>">
                    <?php echo $conn; ?></option>
                        <option value="mysql">MySQL</option>
                        <option value="sqlserver">SQL Server</option>
                        <option value="postgresql">PostgreSQL</option>
                        <option value="mongodb">MongoDB</option>
                    </select>
                </div>
                <div class="col-4">
                    <label>DB Host:</label>
                    <input type="text" class="form-control" name="host" value="<?php echo $host; ?>" />
                    </div>
                <div class="col-4">
                    <label>DB Port:</label>
                    <input type="text" class="form-control" name="port" 
                        value="<?php echo $port; ?>" />
                </div>
                <div class="col-4">
                    <label>DB Name:</label>
                    <input type="text" class="form-control" name="dbname" 
                        value="<?php echo $dbname; ?>" />
                </div>
                <div class="col-4">
                    <label>DB User:</label>
                    <input type="text" class="form-control" name="dbuser" 
                        value="<?php echo $dbuser; ?>" />
                </div>
                <div class="col-4">
                    <label>DB Password:</label>
                    <input type="password" class="form-control" name="pwd" 
                        value="<?php echo $pwd; ?>" />
                </div>
                <div class="col-4">
                    <label>Charset:</label>
                    <input type="text" class="form-control" name="charset" 
                        value="<?php echo $charset; ?>" readonly/>
                </div>
                <div class="col-4">
                    <label>Base URL:</label>
                    <input type="text" class="form-control" name="baseurl" 
                        value="<?php echo $baseurl; ?>" readonly/>
                </div>
                <div class="col-4">
                    <label>Base Path:</label>
                    <input type="text" class="form-control" name="basepath" 
                        value="<?php echo $basepath; ?>" />
                </div>
                <div class="col-4">
                    <label>Project Path:</label>
                    <input type="text" class="form-control" name="projectpath" 
                        value="<?php echo $projectpath; ?>" />
                </div>
                <div class="form-group">
                <button class="save btn btn-large btn-info" type="submit">Update</button>
                <a href="#index" class="btn btn-large btn-default">Cancel</a>
                </div>
            </div>
            
        </form>
    </div>
</div>                                      
<?php
include('html_footer.php');
?>
