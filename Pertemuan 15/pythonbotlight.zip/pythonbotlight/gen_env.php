<?php
include('functions.php');
// Define the path where you want to create the .env file
$filePath = base_path().'config.env';
$out="";

if(isset($_POST['conn'])){
    $conn = $_POST['conn'];
}
if(isset($_POST['host'])){
    $host = $_POST['host'];
}
if(isset($_POST['port'])){
    $port = $_POST['port'];
}
if(isset($_POST['dbname'])){
    $dbname = $_POST['dbname'];
}
if(isset($_POST['dbuser'])){
    $dbuser = $_POST['dbuser'];
}
if(isset($_POST['pwd'])){
    $pwd = $_POST['pwd'];
}
if(isset($_POST['charset'])){
    $charset = $_POST['charset'];
}
if(isset($_POST['pwd'])){
    $pwd = $_POST['pwd'];
}
if(isset($_POST['baseurl'])){
    $baseurl = $_POST['baseurl'];
}
if(isset($_POST['basepath'])){
    $basepath = $_POST['basepath'];
}
if(isset($_POST['projectpath'])){
    $projectpath = $_POST['projectpath'];
}
include('html_header.php');

if (file_exists($filePath)) {
    $out .= "file '$filePath' sudah ada.";
    html_message_warning($out);
} else {
    $envFile = fopen($filePath, 'w');

    if (!$envFile) {
        $out .= "Failed to open .env file for writing.";
        html_message_error($out);
    }

    $variables = [
        "DB_CONNECTION=".$conn,
        "DB_HOST=".$host,
        "DB_PORT=".$port,
        "DB_DATABASE=".$dbname,
        "DB_USERNAME=".$dbuser,
        "DB_PASSWORD=".$pwd,
        "DB_CHARSET=".$charset,
        "BASE_URL=".$baseurl,
        "BASE_PATH=".$basepath,
        "PROJECT_PATH=".$projectpath,
    ];

    foreach ($variables as $variable) {
        fwrite($envFile, $variable . "\n");
    }

    fclose($envFile);
    sleep(2);
    replaceEnvFile();
    sleep(1);
    $directoryPath = $projectpath;

    if (is_dir($directoryPath)) {
        $out = "The folder exists.";
        html_message_warning($out);
    } else {
        mkdir($directoryPath, 0777, true);
        $out = "Project folder created successfully.";
        html_message_success($out);
    }

}

include('html_footer.php');
?>