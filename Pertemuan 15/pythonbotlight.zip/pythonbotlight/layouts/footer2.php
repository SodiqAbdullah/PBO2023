    <!-- JS Files-->
    <script src="assets/js/jquery.min.js"></script>
   
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    

    <!-- Main JS-->
    <script src="assets/js/main.js"></script>


  </body>
</html>