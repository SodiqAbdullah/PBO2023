<!--start sidebar -->
<aside class="sidebar-wrapper" data-simplebar="true">
      <div class="sidebar-header">
        <div>
          <img src="assets/images/logo-icon-2.png" class="logo-icon" alt="logo icon">
        </div>
        <div>
          <h4 class="logo-text">Python App Bot <small>LIGHT</small></h4>
        </div>
      </div>
      <!--navigation-->
      <ul class="metismenu" id="menu">        
        <li class="menu-label">Main Menu</li>
        <li>
            <a href="index.php">
              <div class="parent-icon">
              <i class="lni lni-display-alt"></i>
              </div>
              <div class="menu-title">Dashboard</div>
            </a>
          </li>
          <li>
            <a href="documentation.php">
              <div class="parent-icon">
                <ion-icon name="document-text-outline"></ion-icon>
              </div>
              <div class="menu-title">Documentation</div>
            </a>
          </li>
          <li>
            <a href="documentation.php">
              <div class="parent-icon">
                <ion-icon name="settings-outline"></ion-icon>
              </div>
              <div class="menu-title">Settings</div>
            </a>
          </li>
          
        
        
        
        
      </ul>
      <!--end navigation-->
    </aside>
    <!--end sidebar -->